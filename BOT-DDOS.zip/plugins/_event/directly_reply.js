exports.run = {
	async: async (m, {
		client,
		body,
		Func,
		Scraper
	}) => {
		try {
			if (m.quoted && m.quoted.text && /Direct\sPersonal/.test(m.quoted.text)) {
         if (m.sender === client.decodeJid(client.user.id)) return
         const chat = m.quoted.contextInfo.mentionedJid[0]
         const id = m.quoted.text.split('#')[1].trim()
         const msgs = client.msgs.find(v => v.key.id == id) || null
         if (/conversation|extendedText/.test(m.mtype)) {
            const parse = body.match('•') ? true : false
            if (parse) {
               const text = body.replace('•', '').trim()
               const json = await Scraper.tts(text)
               if (!json.status) return client.reply(chat, text, msgs).then(() => client.sendReact(m.chat, '✅', m.key))
               client.sendFile(m.chat, json.data['URL'], '', '', msgs).then(() => client.sendReact(m.chat, '✅', m.key))
            } else client.reply(chat, body, msgs).then(() => client.sendReact(m.chat, '✅', m.key))
         } else if (m.mtype == 'audioMessage') {
            client.sendFile(m.chat, await m.download(), '', '', msgs).then(() => client.sendReact(m.chat, '✅', m.key))
         } else if (m.mtype == 'stickerMessage') {
            const media = await m.download()
            client.sendSticker(chat, media, msgs, {
               packname: '© Takemii.js',
               author: ''
            }).then(() => client.sendReact(m.chat, '✅', m.key))
         } else {
            const media = await m.download()
            client.sendFile(chat, media, '', body ? body : '', msgs).then(() => client.sendReact(m.chat, '✅', m.key))
         }
      } else if (m.quoted && m.quoted.text && /Direct\sGroup/.test(m.quoted.text)) {
     	if (m.sender === client.decodeJid(client.user.id)) return
         const chat = m.quoted.text.split('jid :')[1].split('\n')[0].trim()
         const id = m.quoted.text.split('#')[1].trim()
         const msgs = client.msgs.find(v => v.key.id == id) || null
         const person = m.quoted.contextInfo.mentionedJid[0]
         if (/conversation|extendedText/.test(m.mtype)) {
            const parse = body.match('•') ? true : false
            if (parse) {
               const text = body.replace('•', '').trim()
               const json = await Scraper.tts(text)
               if (!json.status) return client.reply(chat, text, msgs).then(() => client.sendReact(m.chat, '✅', m.key))
               client.sendFile(m.chat, json.data['URL'], '', '', msgs).then(() => client.sendReact(m.chat, '✅', m.key))
            } else client.reply(chat, body, msgs).then(() => client.sendReact(m.chat, '✅', m.key))
         } else if (m.mtype == 'audioMessage') {
            client.sendFile(m.chat, await m.download(), '', '', msgs).then(() => client.sendReact(m.chat, '✅', m.key))
         } else if (m.mtype == 'stickerMessage') {
            const media = await m.download()
            client.sendSticker(chat, media, msgs, {
               packname: '© Takemii.js',
               author: ''
            }).then(() => client.sendReact(m.chat, '✅', m.key))
         } else {
            const media = await m.download()
            client.sendFile(chat, media, '', body ? '@' + person.replace(/@.+/, '') + ' ' + body : '', msgs, null, {
               mentionedJid: [person]
            }).then(() => client.sendReact(m.chat, '✅', m.key))
         }
      }
		} catch (e) {
			return client.reply(m.chat, Func.jsonFormat(e), m)
		}
	},
	error: false,
	cache: true,
	location: __filename
}