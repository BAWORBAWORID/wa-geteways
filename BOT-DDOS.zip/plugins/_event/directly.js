exports.run = {
   async: async (m, {
      client,
      body,
      isOwner,
      groupMetadata,
      env,
      Func
   }) => {
      try {
         if (!m.isGroup && !isOwner) {
            if (!m.fromMe && m.chat.endsWith('.net') && m.mtype != 'protocolMessage') {
               if (/conversation|extendedText/.test(m.mtype) && body && !env.evaluate_chars.some(v => body.startsWith(v))) {
                  client.reply(env['jid-message'], `Direct Personal From : @${m.sender.replace(/@.+/, '')}\n\n#${m.key.id}`, m).then(async () => {
                     await client.copyNForward(env['jid-message'], m)
                  })
               } else {
                  client.reply(env['jid-message'], `Direct Personal From : @${m.sender.replace(/@.+/, '')}\n\n#${m.key.id}`, m).then(async () => {
                     await client.copyNForward(env['jid-message'], m)
                  })
               }
            }
         }
         if (m.isGroup) {
            let groupName = groupMetadata.subject
            let me = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
            for (let jid of me) {
               if (client.decodeJid(client.user.id) != me) continue
               if (isOwner) continue
               if (/conversation|extendedText/.test(m.mtype) && body && !env.evaluate_chars.some(v => body.startsWith(v))) {
                  client.reply(env['jid-message'], `Direct Group From : @${m.sender.replace(/@.+/, '')} at ${groupName} jid : ${m.chat}\n\n#${m.key.id}`, m).then(async () => {
                     await client.copyNForward(env['jid-message'], m)
                  })
               } else {
                  client.reply(env['jid-message'], `Direct Group From : @${m.sender.replace(/@.+/, '')} at ${groupName} jid : ${m.chat}\n\n#${m.key.id}`, m).then(async () => {
                     await client.copyNForward(env['jid-message'], m)
                  })
               }
            }
         }
      } catch (e) {
         return client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   cache: true,
   location: __filename
}