exports.run = {
   async: async (m, {
      client,
      body,
      chats,
      users,
      setting,
      isOwner,
      env,
      Func,
      Scraper
   }) => {
      try {
         if (body && env.evaluate_chars.some(v => body.startsWith(v)) || body && Func.socmed(body)) return
         global.db.chatroom = global.db.chatroom ? global.db.chatroom : []
         const room = global.db.chatroom.find(v => v.jid == m.sender)
         if (m.isGroup) {
            for (let jid of [...new Set([...(m.mentionedJid || [])])]) {
               if (jid != client.decodeJid(client.user.id)) continue
               if (!m.fromMe) return m.reply('Do you want to chat with me? send *nxr* to create a chat session.')
            }
            if (body && body.toLowerCase() == 'nxr' && !room) {
               return m.reply('✅ Chat session created successfully.\nSend any text then bot will response, to remove chat session send *stop*.').then(() => global.db.chatroom.push({
                  jid: m.sender,
                  created_at: new Date * 1
               }))
            } else if (body && body.toLowerCase() == 'kmi' && room) return m.reply('You have been in a chat session.')
            if (body && body.toLowerCase() == 'stop' && room) return m.reply('✅ Chat session deleted successfully.').then(() => Func.removeItem(global.db.chatroom, room))
            if (room && /conversation|extended/.test(m.mtype)) {
               var json = await Scraper.simsimi(body)
               if (!json.status) {
                  var json = await Scraper.simsimiV2(body)
                  if (!json.status) {
                     var json = await Scraper.chatAI(process.env.BRAIN_API_ID, process.env.BRAIN_API_KEY, body)
                  }
               }
               if (json.status) return client.reply(m.chat, json.msg, m).then(() => room.created_at = new Date * 1)
            }
         } else {
            if (!setting.chatbot || setting.whitelist.includes(m.sender.replace(/@.+/, '')) || isOwner || !/conversation|extended/.test(m.mtype)) return
            var json = await Scraper.simsimi(body)
            if (!json.status) {
               var json = await Scraper.simsimiV2(body)
               if (!json.status) {
                  var json = await Scraper.chatAI(process.env.BRAIN_API_ID, process.env.BRAIN_API_KEY, body)
               }
            }
            if (json.status) return client.reply(m.chat, json.msg, m)
         }
      } catch (e) {
         console.log(e)
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   cache: true,
   location: __filename
}