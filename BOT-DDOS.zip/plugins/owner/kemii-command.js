exports.run = {
   usage: ['off', 'on'],
   use: 'command',
   category: 'owner',
   async: async (m, {
      client,
      args,
      isPrefix,
      command,
      plugins,
      Func
   }) => {
      let cmd = global.db.setting
      if (!args || !args[0]) return client.reply(m.chat, Func.example(isPrefix, command, 'tiktok'), m)
      let commands = Func.arrayJoin(Object.values(Object.fromEntries(Object.entries(plugins).filter(([name, prop]) => prop.run.usage))).map(v => v.run.usage))
      if (!commands.includes(args[0])) return client.reply(m.chat, Func.texted('bold', `🚩 Command ${isPrefix + args[0]} tidak ada.`), m)
      if (command == 'off') {
         if (cmd.error.includes(args[0])) return client.reply(m.chat, Func.texted('bold', `🚩 ${isPrefix + args[0]} command ini sudah di nonaktifkan sebelumnya.`), m)
         cmd.error.push(args[0])
         client.reply(m.chat, Func.texted('bold', `🚩 Command ${isPrefix + args[0]} success di aktifkan.`), m)
      } else if (command == 'on') {
         if (!cmd.error.includes(args[0])) return client.reply(m.chat, Func.texted('bold', `🚩 Command ${isPrefix + args[0]} tidak ada.`), m)
         cmd.error.forEach((data, index) => {
            if (data === args[0]) cmd.error.splice(index, 1)
         })
         client.reply(m.chat, Func.texted('bold', `🚩 Command ${isPrefix + args[0]} success di aktifkan.`), m)
      }
   },
   owner: true
}