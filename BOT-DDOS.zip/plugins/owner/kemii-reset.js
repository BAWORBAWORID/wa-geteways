exports.run = {
   usage: ['reset'],
   category: 'owner',
   async: async (m, {
      client,
      args,
      command,
      setting,
      env,
      Func
   }) => {
      try {
         global.db.chats.map(v => v.lastreply = 0)
         client.reply(m.chat, Func.texted('bold', `🚩 Successfully reset last reply to default.`), m)
      } catch (e) {
         return client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   owner: true,
   cache: true,
   location: __filename
}