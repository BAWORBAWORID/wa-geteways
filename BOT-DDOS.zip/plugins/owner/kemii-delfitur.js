let path = require("path");
let fs = require("fs");

exports.run = {
   usage: ['df'],
   use: 'text',
   category: 'owner',
   async: async (m, {
      client,
      setting,
      args,
      text,
      command,
      isPrefix,
      Func
   }) => {
   if (!text) return client.reply(m.chat, `• *Example :* ${isPrefix + command} plugins/creator.js`, m)
   let filePath = path.join(process.cwd(), text)
   if (!fs.existsSync(filePath)) {
   return m.reply('File/Folder Not Found!')
   }
   if (fs.statSync(filePath).isDirectory()) {
   fs.rmdirSync(filePath, { recursive: true })
   } else {
   fs.unlinkSync(filePath)
   }
   client.reply(m.chat, `🚩 Sukses Delete ${text}!`, m)
   },
   owner: true
}