let fs = require('fs')

exports.run = {
   usage: ['sf'],
   use: 'text',
   category: 'owner',
   async: async (m, {
      client,
      setting,
      args,
      text,
      command,
      isPrefix,
      Func
   }) => {
   if (!text) return client.reply(m.chat, `• *Example :* ${isPrefix + command} owner/ddos`, m)
   try {
   if (!m.quoted.text) return client.reply(m.chat, `🚩 Reply Code Message!`, m)
   let path = `plugins/${text}.js`
   await fs.writeFileSync(path, m.quoted.text)
   client.reply(m.chat, `🚩 Saved in ${path}`, m)
   } catch (error) {
   console.log(error)
   client.reply(m.chat, "🚩 Reply Code Message!", m)
   }
   },
   owner: true
}