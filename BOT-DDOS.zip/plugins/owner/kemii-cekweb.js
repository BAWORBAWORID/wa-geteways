let fetch = require('node-fetch');

exports.run = {
   usage: ['cekweb'],
   use: 'link',
   category: 'owner',
   async: async (m, {
      client,
      command,
      isPrefix,
      text,
      Func
   }) => {
   if (!text) return client.reply(m.chat, Func.example(isPrefix, command, 'https://kemii.my.id'), m);
   client.sendReact(m.chat, '🕒', m.key)
   let kemii = await fetch(`https://api.yanzbotz.my.id/api/tools/iplook?url=${text}`)
   let hasil = await kemii.json()
   if (hasil.result.asname === "CLOUDFLARENET") return client.reply(m.chat, '```❎ Web ini tidak bisa di ddos.```', m)
   client.reply(m.chat, '```✅ Web ini bisa di ddos.```', m)
   },
   error: false,
   owner: true,
   cache: true,
   location: __filename
}