exports.run = {
   usage: ['m', 'menu'],
   category: 'main',
   async: async (m, {
      client,
      isPrefix,
      command,
      setting,
      plugins,
      Func
   }) => {
      try {
         if (command === 'm') {
            let cmd = Object.entries(plugins).filter(([_, v]) => v.run.usage && v.run.category === 'owner' && !setting.hidden.includes(v.run.category.toLowerCase()))
            let usage = Object.keys(Object.fromEntries(cmd))
            if (usage.length == 0) return
            let commands = []
            cmd.map(([_, v]) => {
               switch (v.run.usage.constructor.name) {
                  case 'Array':
                     v.run.usage.map(x => commands.push({
                        usage: x,
                        use: v.run.use ? Func.texted('bold', v.run.use) : ''
                     }))
                     break
                  case 'String':
                     commands.push({
                        usage: v.run.usage,
                        use: v.run.use ? Func.texted('bold', v.run.use) : ''
                     })
               }
            })
            let print = commands.sort((a, b) => a.usage.localeCompare(b.usage)).map((v, i) => {
               if (i == 0) {
                  return `┌  ◦  ${isPrefix + v.usage} ${v.use}`
               } else if (i == commands.sort((a, b) => a.usage.localeCompare(b.usage)).length - 1) {
                  return `└  ◦  ${isPrefix + v.usage} ${v.use}`
               } else {
                  return `│  ◦  ${isPrefix + v.usage} ${v.use}`
               }
            }).join('\n')
            m.reply(print)
         } else if (command === 'menu') {
            let cmd = Object.entries(plugins).filter(([_, v]) => v.run.usage && v.run.category === 'feature' && !setting.hidden.includes(v.run.category.toLowerCase()))
            let usage = Object.keys(Object.fromEntries(cmd))
            if (usage.length == 0) return
            let commands = []
            cmd.map(([_, v]) => {
               switch (v.run.usage.constructor.name) {
                  case 'Array':
                     v.run.usage.map(x => commands.push({
                        usage: x,
                        use: v.run.use ? Func.texted('bold', v.run.use) : ''
                     }))
                     break
                  case 'String':
                     commands.push({
                        usage: v.run.usage,
                        use: v.run.use ? Func.texted('bold', v.run.use) : ''
                     })
               }
            })
            let print = commands.sort((a, b) => a.usage.localeCompare(b.usage)).map((v, i) => {
               if (i == 0) {
                  return `┌  ◦  ${isPrefix + v.usage} ${v.use}`
               } else if (i == commands.sort((a, b) => a.usage.localeCompare(b.usage)).length - 1) {
                  return `└  ◦  ${isPrefix + v.usage} ${v.use}`
               } else {
                  return `│  ◦  ${isPrefix + v.usage} ${v.use}`
               }
            }).join('\n')
            const msg = (setting.dial.length >= 1) ? '› ' + Func.Styles('Send number to view content :') + '\n\n' + setting.dial.sort((a, b) => a.created_at - b.created_at).map((v, i) => `${i + 1} – ${v.title}`).join('\n') + '\n\n' + String.fromCharCode(8206).repeat(4001) + Func.Styles(print.trim()) + '\n\n' + global.footer : Func.Styles(print.trim()) + '\n\n' + global.footer
            if (setting.style === 1) {
               m.reply(msg)
            } else if (setting.style === 2) {
               client.sendMessageModify(m.chat, msg, m, {
                  ads: false,
                  largeThumb: true,
                  thumbnail: setting.cover,
                  url: 'contact@kemii.my.id'
               })
            } else if (setting.style === 3) {
               client.sendProgress(m.chat, msg, m)
            } else if (setting.style === 4) {
               client.sendFDoc(m.chat, msg, m)
            }
         }
      } catch (e) {
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   cache: true,
   location: __filename
}