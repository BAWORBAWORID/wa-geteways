const moment = require('moment-timezone')
exports.run = {
   usage: ['botstat'],
   hidden: ['stat'],
   category: 'miscs',
   async: async (m, {
      client,
      blockList,
      setting,
      ctx,
      Func
   }) => {
      let users = global.db.users.length
      let chats = global.db.chats.filter(v => v.jid.endsWith('.net')).length
      let groupList = async () => Object.entries(await client.groupFetchAllParticipating()).slice(0).map(entry => entry[1])
      let groups = await (await groupList()).map(v => v.id).length
      const stats = {
         users,
         chats,
         groups,
         cmd: ctx.commands.length,
         blocked: blockList.length,
         receiver: global.db.setting.receiver.length,
         spy: global.db.setting.spy.length,
         except: global.db.setting.except.length,
         product: global.db.setting.product.length,
         response: global.db.setting.response.length,
         dial: global.db.setting.dial.length,
         marked: global.db.setting.whitelist.length,
         uptime: Func.toTime(process.uptime() * 1000)
      }
      const system = global.db.setting
      client.sendMessageModify(m.chat, statistic(stats, system, Func), m, {
         largeThumb: true,
         thumbnail: setting.cover,
         url: 'contact@kemii.my.id'
      })
   },
   error: false,
   cache: true,
   location: __filename
}

const statistic = (stats, system, Func) => {
   return ` –  *B O T S T A T*

┌  ◦  ${Func.texted('bold', Func.formatter(stats.groups))} Groups Joined
│  ◦  ${Func.texted('bold', Func.formatter(stats.chats))} Personal Chats
│  ◦  ${Func.texted('bold', Func.formatter(stats.users))} Users In Database
│  ◦  ${Func.texted('bold', Func.formatter(stats.blocked))} Users Blocked
│  ◦  ${Func.texted('bold', Func.formatter(stats.marked))} Users Marked
│  ◦  ${Func.texted('bold', Func.formatter(stats.receiver))} Users In Receiver
│  ◦  ${Func.texted('bold', Func.formatter(stats.spy))} Users In Spy
│  ◦  ${Func.texted('bold', Func.formatter(stats.except))} Users In Except
│  ◦  ${Func.texted('bold', Func.formatter(stats.response))} Response
│  ◦  ${Func.texted('bold', Func.formatter(stats.product))} Products
│  ◦  ${Func.texted('bold', Func.formatter(stats.dial))} Dial Messages
│  ◦  ${Func.texted('bold', Func.formatter(stats.cmd))} Available Commands
└  ◦  Runtime : ${Func.texted('bold', stats.uptime)}

 –  *S Y S T E M*

┌  ◦  ${Func.texted('bold', system.online ? '[ √ ]' : '[ × ]')}  Always Online
│  ◦  ${Func.texted('bold', system.autoreadpc ? '[ √ ]' : '[ × ]')}  Auto Read Chat
│  ◦  ${Func.texted('bold', system.autoreadgc ? '[ √ ]' : '[ × ]')}  Auto Read Group
│  ◦  ${Func.texted('bold', system.chatbot ? '[ √ ]' : '[ × ]')}  Chatbot
│  ◦  ${Func.texted('bold', system.debug ? '[ √ ]' : '[ × ]')}  Debug Mode
│  ◦  ${Func.texted('bold', system.greeting ? '[ √ ]' : '[ × ]')}  Greeting
│  ◦  ${Func.texted('bold', system.lock ? '[ √ ]' : '[ × ]')}  Lock Response
│  ◦  ${Func.texted('bold', system.noprefix ? '[ √ ]' : '[ × ]')}  No Prefix
│  ◦  ${Func.texted('bold', system.multiprefix ? '[ √ ]' : '[ × ]')}  Multi Prefix
│  ◦  ${Func.texted('bold', system.self ? '[ √ ]' : '[ × ]')}  Self Mode
│  ◦  ${Func.texted('bold', system.silent ? '[ √ ]' : '[ × ]')}  Silent Mode
│  ◦  ${Func.texted('bold', system.viewstory ? '[ √ ]' : '[ × ]')}  Story Viewer
│  ◦  ${Func.texted('bold', system.forwardstory ? '[ √ ]' : '[ × ]')}  Story Forwarder
└  ◦  Prefix : ${Func.texted('bold', system.multiprefix ? '( ' + system.prefix.map(v => v).join(' ') + ' )' : '( ' + system.onlyprefix + ' )')}

${global.footer}`
}