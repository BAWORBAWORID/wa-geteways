let fetch = require('node-fetch')
let googleIt = require('google-it')

exports.run = {
   usage: ['google'],
   use: 'query',
   category: 'feature',
   async: async (m, {
      client,
      command,
      isPrefix,
      text,
      Func
   }) => {
   if (!text) return client.reply(m.chat, Func.example(isPrefix, command, 'dcode-kemii'), m);
   client.sendReact(m.chat, '🕒', m.key)
   let url = 'https://google.com/search?q=' + encodeURIComponent(text)
   let search = await googleIt({ query: text })
   let msg = search.map(({ title, link, snippet}) => {
    return `*${title}*\n_${link}_\n_${snippet}_`
  }).join`\n\n`
   let ss = `https://api.apiflash.com/v1/urltoimage?access_key=80145ab3eded44bdb0dbb14ee209f3b8&wait_until=page_loaded&url=${url}`
   await client.sendFile(m.chat, ss, '', msg, m)
   },
   error: false,
   location: __filename
}