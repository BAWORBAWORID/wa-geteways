let { openai } = require('betabotz-tools')

exports.run = {
   usage: ['ai'],
   use: 'text',
   category: 'feature',
   async: async (m, {
      client,
      setting,
      args,
      text,
      command,
      isPrefix,
      Func
   }) => {
   if (!text) return client.reply(m.chat, Func.example(isPrefix, command, 'Hallo'), m);
   client.sendReact(m.chat, '🕒', m.key)
   let hasil = await openai(text)
   client.reply(m.chat, hasil.result, m)
   },
   error: false,
   cache: true,
   location: __filename
}